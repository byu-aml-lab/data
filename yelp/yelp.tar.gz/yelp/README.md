10 Feb 2016

We got this data from Thang Nguyen.

yelp.txt contains all of the reviews, one per line.  On each line, there is an
identification tag followed by a tab character followed by the text of the
review.

yelp.response contains the corresponding star rating.  On each line, there is an
identification tag followed by a tab character followed by the star rating.
